## Eko Atlantic City

[Eko Atlantic](https://en.wikipedia.org/wiki/Eko_Atlantic) is an entire new coastal city being built on Victoria Island adjacent to Lagos, Nigeria. It is a focal point for investors capitalising on rich development growth based on massive demand – and a gateway to emerging markets of the continent.

Standing on 10 million square metres of land reclaimed from the ocean and protected by an 8.5 kilometre long sea wall, Eko Atlantic will be the size of Manhattan’s skyscraper district. Self-sufficient and sustainable, it includes state-of-the-art urban design, its own power generation, clean water, advanced telecommunications, spacious roads, and tree-lined streets.