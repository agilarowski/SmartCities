## Eastern Economic Corridor

[The Eastern Economic Corridor](https://en.wikipedia.org/wiki/Eastern_Economic_Corridor) (EEC) development lies at the heart of Thailand 4.0 scheme. The project is an area-based development initiative, aiming to revitalize the well-known Eastern Seaboard where, for 30 years, numerous business developers have experienced a rewarding investment journey and exceptional achievements.

The project initially focused on the 3 Eastern provinces, namely Rayong, Chonburi, and Chachoengsao. The EEC development plan envisages a significant transformation of both physical and social development, plays an important role as a regulatory sandbox uplifting the country’s competitiveness.

The EEC’s 12 targeted S-curve industries are: cars; smart electronics; affluent, medical and wellness tourism; agriculture and biotechnology; food; robotics for industry; logistics and aviation; biofuels and biochemicals; digital; medical services; defense; and education development.