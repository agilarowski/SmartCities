let map, tileLayer;
map = L.map("smart-cities-map");
tileLayer = L.tileLayer("https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png", {
              attribution: "&copy; <a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a> &copy; <a href='http://carto.com/attribution'>CARTO</a>",
              subdomains: "abcd",
              maxZoom: 18
            }).addTo(map);
map.setView([40.730833, -73.9975], 16);

// Define the features array.
let smartCitiesFeatures;
$.getJSON("smart-cities.json", function(data){
  // Define the Leaflet layer.
  let smartCitiesLayer;
  // Iterate over the .features property of the GeoJSON object to
  // create an array of objects (features), with every object’s
  // properties as noted.
  smartCitiesFeatures = data.features.map(function(feature){
    // This return returns an object.
    return {
      name: feature.properties.name,
      html: feature.properties.html,
      tab: feature.properties.tab,
      continent: feature.properties.continent,
      country: feature.properties.country,
      wikipedia: feature.properties.wikipedia,
      // Create an L.latLng object out of the GeoJSON coordinates.
      // Remember that in GeoJSON, the coordinates are reversed
      // (longitude, then latitude).
     latLng: L.latLng(feature.geometry.coordinates[1], feature.geometry.coordinates[0])
      //latLng: L.latLng(feature.geometry.coordinates[0], feature.geometry.coordinates[1])
    };
  });
  console.log(smartCitiesFeatures);
  // Now create a Leaflet feature group made up of markers for each
  // object in couldBeFeatures.
  smartCitiesLayer = L.featureGroup(smartCitiesFeatures.map(function(feature){
    return L.marker(feature.latLng);
    })
  )
  // Add the layer to the map.
  smartCitiesLayer.addTo(map);
  // Redraw the map so that all the markers are visible.
  map.fitBounds(smartCitiesLayer.getBounds());
  // Zoom out one level to give some padding.
  map.zoomOut(1);

/*let md;
  md = window.markdownit({html: true}).use(window.markdownitFootnote);
// Load the Markdown file with jQuery.
  $.ajax({
  url: "forest-city-johor.md",
  success: function(markdown){
    // Convert the Markdown to HTML.
    let html;
    html = md.render(markdown);
    // Print the HTML to #content using jQuery.
    $("#content").html(html);
  }});
*/

let md;
md = window.markdownit({html: true}).use(window.markdownitFootnote);
let curLatLng = 0;
var citiesByTab = {}
 var rightCity;
 var sCFlength = smartCitiesFeatures.length;
 var tabString;
 var curCity;
 
  for(i = 0; i<sCFlength; i++) {
    tabString = smartCitiesFeatures[i].tab;
    curCity = smartCitiesFeatures[i];
//    Object.defineProperty(citiesByTab, tabString,
//      curCity);
    citiesByTab[tabString] = curCity;
   // citiesByTab.{smartCitiesFeatures[i].tab} = smartCitiesFeatures[i];
  }
  console.log(citiesByTab);

["akon-city","tianfu","belmont","binhai-new-area","liangjiang-new-area","wakanda-city-of-return","mulberry-l-zone-smart-city-new-delhi","new-yangon-city-development",
"eastern-economic-corridor","neom","masdar","new-clark-city","robotic-new-city","new-silk-road-city-of-khorgos",
"sino-singapore-guangzhou-knowledge-city","sino-singapore-tianjin-eco-city","sino-oman-industrial-city","forest-city","colombo-port-city","sondgo",
"forest-city-johor","new-cairo","gracefield-island","new-administrative-capital",
"centenary-city","eko-atlantic-city","lanseria-smart-city","new-alamein-city",
"waterfall-city","mohammed-VI-tangier-tech-city"].forEach(function(tab){
  console.log(tab);

  // Create a variable tab that has the name as a string.
  $.ajax({
    // tab + ".md" yields, for example, "rampart.md".
 //   url: "http://127.0.0.1:5500/Smart_Cities/" + tab + ".md",
    url: tab + ".md",
    success: function(markdown){
      rightCity = citiesByTab[tab];
      console.log(rightCity);
      let html;
      html = md.render(markdown);
      // "#rampart", for example.
      $("#" + tab).html(html);
      console.log(rightCity);
      if(typeof rightCity != "undefined") {
        console.log(tab);
        if(rightCity.hasOwnProperty('latLng')) {
          // $("a[href$='.org']")
          console.log(tab);
          var attrName = '';
          var targeter = "a[href$='"+tab+"']";
          $(targeter).attr('data-tab', tab);
          $(targeter).attr('data-lat', rightCity.latLng.lat);
          $(targeter).attr('data-lng', rightCity.latLng.lng);
          $(targeter).click( 
            focusMapCity
           // function(){ focusMapCity(e); }
          );
          /*  function(){
              alert(tab);
            
             map.setView([rightCity.latLng.lat, rightCity.latLng.lng], 13);}
            );*/
        
      }

    }
  }
  });
  curLatLng = 0;
});


});


function focusMapCity(e) {
  t = e.target;
  let lat = t.getAttribute('data-lat');
  let long = t.getAttribute('data-lng');
 // map.lat = lat;
 // map.long = long;
  console.log(map);
 // map.setView(lat, long, 13);
 // map.panTo([lat, long]);
  map.setView([lat, long], 7);
  //map.setView([long, lat], 16);
}
