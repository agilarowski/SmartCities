## Colombo Port City

Built on reclaimed land, [Colombo Port City](https://en.wikipedia.org/wiki/Port_City_Colombo) artificially extends Sri Lanka’s coastline more than 200 hectares into the Indian Ocean. The new city sits on the world’s busiest shipping route, 
with access to east Asia, Africa and the Middle east, adding to the strategic collection of newly aquired Chinese ports stretching from Asia to Europe. Colombo Port City is strategically
 positioned to become one of the most prominent finance and trade centres in the region, boasting independent investment legislation and policies. The development could reset Sri Lanka’s 
 economic and geopolitical position in the world.