## Cwntenary City

The [Abuja Centenary City](https://en.wikipedia.org/wiki/Centenary_City) will be the financial hub of the capital of Nigeria.
An efficient business enclave will position Nigeria as a key player in the global financial arena. The new city will be sustainable because it balances economic, social, cultural and environmental factors to produce harmonic development.

The basic strategy in the design is the concentration of corporate and commercial buildings and dispersion of living and service areas around the centre. A large number of mixed-use mid-rises and high-rises in the central core of the new city.