## New Silk Road City of Khorgos

A new town, called [Nurkent](https://www.nytimes.com/2018/01/01/world/asia/china-kazakhstan-silk-road.html), has been built from scratch — with apartment blocks, a school, kindergarten and shops to serve the railway workers, crane operators, customs officials and other staff needed to keep the dry port running. Free housing is provided. The town currently has only around 1,200 residents, but there are plans to expand it for more than 100,000.

Zhaslan Khamzin, the chief executive of the company operating the dry port with help from DP World of Dubai, acknowledged that the place seemed inhospitable but, implausibly describing it as an “oasis,” insisted, “This is the future.”