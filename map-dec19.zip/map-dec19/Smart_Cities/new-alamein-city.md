## New Alamein City

The [New Alamein City](https://en.wikipedia.org/wiki/New_Alamein) is located in the North Coast and is set to be the first of its kind in the area. Designed to the high standards of what is called a fourth-generation city, the New Alamein City is planned to hold millions of residents, hitting a new milestone for the North Coast area. It comes with the new concept of an open-to-the-public tourism city on the North Coast, taking a different approach than the private resorts spread across the sea line.

Orascom Construction is progressing in the construction of 3 commercial projects (towers, hotels and historical cities) with a total built-up area of about 737,000 m2, in addition to a wastewater treatment plant with a capacity of 90,000 m3 per day.
