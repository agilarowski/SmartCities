## Wakanda City of Return

The [Wakanda City of Return](https://citinewsroom.com/2021/04/wakanda-city-of-return-to-start-in-august-2021/) project which was launched a year ago by the African Diasporia Development Institute (ADDI), Cape Coast Metropolitan Assembly and other local partners Pelicape Group and

Adepa Investment is scheduled to begin in August this year.

The project is expected to create about 5,000 direct and indirect jobs and open opportunities in Africa and beyond to boost tourism development.