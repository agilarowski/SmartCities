## Sino-Singapore Tianjin Eco-City

The [Sino-Singapore Tianjin Eco-city’s](https://en.wikipedia.org/wiki/Sino-Singapore_Tianjin_Eco-city) vision is to be a thriving city which is socially harmonious, environmentally-friendly and resource-efficient – a model for sustainable development. This vision is underpinned by the concepts of Three Harmonies and Three Abilities.

Three Harmonies refer to

People living in harmony with other people, i.e. social harmony;
People living in harmony with economic activities, i.e. economic vibrancy; and
People living in harmony with the environment, i.e. environmental sustainability.

Three Abilities refer to the Eco-city being

Practicable: the technologies adopted in the Eco-city must be affordable and commercially viable;
Replicable: the principles and models of the Eco-city could be applied to other cities in China and in other countries; and
Scalable: the principles and models could be adapted for another project or development of a different scale.