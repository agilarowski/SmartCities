## Akon City

[AKON CITY](https://en.wikipedia.org/wiki/Akon_City,_Senegal) project seeks to address the need for vibrant new community development, with a vision to create a Business district, residential districts (high-rise ) education district, healthcare district, technology district, Media district, entertainment district and sport facilities with a recreational enclave for the surrounding area to address the market need for the development in Senegal.

The developed economy aims to adapt future development. The current evolution required a flexible infrastructure to accommodate new real estate development. The fast pace of global changes, economic progress, Poverty, and technology race, continuously causing Senegal to face various new challenges.

 AKONCITY will play a vital role in the quest for solutions to these challenges. The knowledge we generate and the professionals we train are expected, and quite rightly, to help in providing local solutions as well as a critical component of human development.

 

 It is these professional’s individuals who develop the capacity and analytical skills that drive local economies, create new industries, support civil society, lead capable governments, and make critical decisions that will affect the entire economy.