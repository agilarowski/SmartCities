## Lanseria Smart City

The [Lanseria Smart City](https://storymaps.arcgis.com/stories/cbc7678cb3e44748b0d9089e39248368) will feature rainwater harvesting and solar energy to limit its carbon footprint.

The city aims to move urban sustainability beyond existing paradigms of planning, engineering, and urbanization to increasingly appropriate levels of sustainability and innovation. There is a strong focus on limiting the need to commute using cars. Any commuting should, by default, be by non-motorised means like walking or cycling or, where necessary, by public transport.

In planning terms, this means the new city needs to be walkable. People must be able to walk to work, shopping malls, or schools, within between 5 minutes (400 metres) and 10 minutes (800 metres). The Lanseria Business Gateway will be located on 130 hectares of prime real estate between Lanseria Airport and the upmarket Blair Atholl Golf Estate.

It will be a 24-hour smart city zone that will offer retail, conference, and business facilities. It will also host the Lanseria luxury hotel.