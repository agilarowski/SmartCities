## Liangjiang New Area

[Liangjiang New Area](https://en.wikipedia.org/wiki/Liangjiang_New_Area) is China's first inland national-level new area. It covers an area of 1,200 square kilometers, including regions of Jiangbei, Yubei and Beibei districts. Liangjiang's permanent resident population was 2.7 million people in 2020.