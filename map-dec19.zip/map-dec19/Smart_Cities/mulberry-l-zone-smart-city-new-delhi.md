## Mulberry L Zone Smart City New Dehli

[Mulberry](https://smartcityhousing.wordpress.com/mulberry-dwarka/) is meticulously planned to always keep you closer to nature. Seamless greens and enveloping landscapes are a refreshing sight. Mulberry is designed to provide happy homes with healthy and glorious lifestyles located in the smart city Delhi. L-Zone of Delhi located near dwarka is all set to be the smart city that uses digital technologies to enhance performance and well being to reduce costs and resource.
