## Gracefield Island

[Gracefield Island](https://en.wikipedia.org/wiki/Gracefield_Island) ia a purpose built island sitting on 60 hectares of land space in its early phase, with prospect of expanding to a bigger size within its designated zone on the Lekki Masterplan of Lagos State Government.
Gracefield island is 2.3 kilometres into the lagoon from the shoreline of Chevron. The 2.3 kilometre landbridge constructed by Gravitas Investments, the city developer gives it a distinct identity of a true island and creates a positive welcome effect on residents and visitors.