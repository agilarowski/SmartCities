## New Administrative Capital

The Egyptian government will start the process in December of moving offices to a [new administrative capital](https://en.wikipedia.org/wiki/New_Administrative_Capital) located east of Cairo, a spokesman for the presidency said on Wednesday in a statement. President Abdel Fattah al-Sisi "directed the government to start the actual transfer to the government district in the New Administrative Capital starting in December for a trial period of 6 months," he said. The new capital is designed as a high-tech "smart city" to accommodate 6.5 million residents and ease congestion in Cairo. The city will include a government district, a business district, vast parks and a diplomatic district.

