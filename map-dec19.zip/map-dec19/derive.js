let firstMap, tileLayer;
firstMap = L.map("first-map");
tileLayer =
L.tileLayer("https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png", {
      attribution: "&copy; <a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a> &copy; <a href='http://carto.com/attribution'>CARTO</a>",
      subdomains: "abcd",
      maxZoom: 18
    });
tileLayer.addTo(firstMap);
firstMap.setView([40.77251, -73.96704], 13);

let EastWalk, WestWalk;
let EastWalkCoor, WestWalkCoor;

EastWalkCoor = [
    [[40.77251, -73.96704],
    [40.76437, -73.97303],
    [40.76691, -73.97910],
    [40.76111, -73.98325],
    [40.75991, -73.98044]
],
    [
    [40.70242, -74.01382],
    [40.70246, -74.01285],
    [40.70300, -74.01152],
    [40.70521, -74.00740],
    [40.70577, -74.00835],
    [40.70640, -74.00953]]
];

EastWalk=L.polyline(EastWalkCoor, {color: "green"}
).addTo(firstMap);

WestWalkCoor = [
    [40.77942, -73.97736],
    [40.77113, -73.98337],
    [40.77234, -73.98625],
    [40.77107, -73.98717],
    [40.76987, -73.98438],
    [40.76903, -73.98232],
];
WestWalk=L.polyline(WestWalkCoor, {color: "red"}
).addTo(firstMap);

